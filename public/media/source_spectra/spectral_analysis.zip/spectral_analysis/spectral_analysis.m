%%% script for the spectra analysis
%%% required functions: readsac_com.m
%%% Suli Yao 10/03/2022
%%% usage: >>>spectral_analysis

clear all;close all;

% add the path to the scripts
path='/Users/suliyao/Desktop/spectral_analysis'; % the path to the tutorial package
addpath('/Users/suliyao/Desktop/spectral_analysis/depth_phase');

% access to the folder with data
cd /Users/suliyao/Desktop/spectral_analysis/Iran_STN/
%%%read in and plot the raw waveforms %%%%%%%%%%

%% read the sac file names
file_choose=dir('*.SAC');
%file_choose=file_choose(1:2:170,:);
nfile = length(file_choose);

%% read the first arrival,azimuth, and sampling interval on each stations
for i=1:nfile
[t,a,p] = readsac_com(file_choose(i).name);
az(i)=p(26); % the azimuth 
tp(i)=p(7); % the first arrival time
int(i)=p(1); % the sampling interval
depth(i)=p(24); %depth of the source
dist(i)=p(25)/111.195;% epicenter distance in degree
end

%%plot the waveforms, aligned by the azimuth, mark the first p arrival
figure;
for i=1:nfile
plot(t,a*300000+az(i),'color',[0.5,0.5,0.5],'LineWidth', 0.1);hold on;
plot(tp(i),az(i),'*red');
xlabel('time (s)');ylabel('Azimuth');title('displacement waveforms');
xlim([0 360]); ylim([-5 370]);
end

print ('-dpdf','waveform.pdf');close all;

%%% preprocessing and calculate spectra%%%%%%%%%
%% define the time window for each station, cut and taper
window_length=40; % 70s windows from the arrival, for the spectral analysis
taper_width=15; % taper waveforms in 5s windows outside the windows for spectral analysis
datalength=8192;    %%length of data
time=0:int(1):((datalength-1)*int(1));

figure;
for i=1:nfile
    [t,a,p] = readsac_com(file_choose(i).name);
    startpoint(i)= round([(tp(i)-taper_width-t(1))/int(i)+1]);
    endpoint(i)=round([(tp(i)+taper_width+window_length-t(1))/int(i)+1]);
    
     cut=a(startpoint(i):endpoint(i));
     cut=taper_com(cut,taper_width/(window_length+2*taper_width)); % taper waveforms
     acut(i,:)=[cut,zeros(1,datalength-size(cut,2))];
     
     % plot waveforms after cutting and taper, aligned by the first arrival
     plot(time,acut(i,:)*300000+az(i),'color',[0.5,0.5,0.5],'LineWidth', 0.1);hold on;
    xlabel('time (s)');ylabel('Azimuth');title('displacement waveforms after cut and taper');
    xlim([0 110]); ylim([-5 370]);
end

print('-dpdf','waveform_cut.pdf');close all;

%% calculate and plot the spectra for each waveforms
figure;
for i=1:nfile
[amp(i,:),ph(i,:),ffn]=sacfft(acut(i,:),time);
amp(i,:)=log10(amp(i,:));
semilogx(ffn,amp(i,:),'-','linewidth',0.3,'color',[0.6,0.6,0.6]);hold on;
xlabel('frequency (Hz)'); ylabel('amplitude'); title('raw spectra');
xlim([0.007,1]);
end
semilogx(ffn,mean(amp),'-','linewidth',3,'color','red');
print('-dpdf','raw_spetral.pdf');close all;


%%% correction for the amplitude %%%%%

%M=[-0.2170,0.0566,-0.9585;0.0566,0.0069,0.1800;-0.9585,0.1800,0.2098]; % the normalized moment tensor
load('M.mat');%load the moment tensor
%% correct for radiation pattern and spherical spreading
figure;
for i=1:nfile
[radiation_P,raylength,anp_p(i)]=direct_P(dist(i),depth(i),az(i),M,path);% anp_p: the amplitude of spreading term and radiation pattern;
amp1(i,:)=amp(i,:)-log10(abs(anp_p(i)));
semilogx(ffn,amp1(i,:),'-','linewidth',0.3,'color',[0.6,0.6,0.6]);hold on;
xlabel('frequency (Hz)'); ylabel('amplitude (log10(Nm))'); title('correction for spreading and radiation pattern');
xlim([0.007,1]);
end
semilogx(ffn,mean(amp1),'-','linewidth',3,'color','red');
print('-dpdf','after_correction_for_spreading_radiation.pdf');close all;

%%% corection for waveform shape %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%correctio for the attenuation
ff=@corre; %% the function to calculate the correction; a global attenuation model
attenuation_corr=ff(ffn);

figure;
for i=1:nfile
amp2(i,:)=amp1(i,:)-log10(attenuation_corr);
semilogx(ffn,amp2(i,:),'-','linewidth',0.3,'color',[0.6,0.6,0.6]);hold on;
xlabel('frequency (Hz)'); ylabel('amplitude (log10(Nm))'); title('correction for attenuation');
xlim([0.007,1]);
end
semilogx(ffn,mean(amp2),'-','linewidth',3,'color','red')
print('-dpdf','after_correction_for_attnuation.pdf');close all;

figure;
semilogx(ffn,log10(attenuation_corr),'-','linewidth',3,'color','blue')
xlabel('frequency (Hz)'); ylabel('amplitude (log10(Nm))'); title('attenuation term');
xlim([0.007,1]);
print('-dpdf','attnuation_term.pdf');close all;


%correctiob for the depth phase
figure;
for i=1:nfile
[depth_time,depth_phase,anp_dep,ph_dep,ffn_dep]=depth_phase_spectrum(file_choose(i).name,window_length,datalength,M,path); %%depth_phase spectrum
amp3(i,:)=amp2(i,:)-log10(anp_dep);
semilogx(ffn,amp3(i,:),'-','linewidth',0.3,'color',[0.6,0.6,0.6]);hold on;
 xlabel('frequency (Hz)'); ylabel('amplitude log10(Nm)'); title('after correction for depth phases');
 xlim([0.007,1]);
end
semilogx(ffn,mean(amp3),'-','linewidth',3,'color','red');
print('-dpdf','depth_pahse_correction.pdf');close all;

% check the depth phases
figure;
for i=1:nfile
[depth_time,depth_phase,anp_dep,ph_dep,ffn_dep]=depth_phase_spectrum(file_choose(i).name,window_length,datalength,M,path); %%depth_phase spectrum
plot(depth_time,depth_phase*10+az(i),'color',[0.6,0.6,0.6]);hold on;xlabel('time');ylabel('azimuth');xlim([0 200]); title ('synthetic depth phases')
end
print ('-dpdf','depth_phase.pdf');close all;

figure;
for i=1:nfile
[depth_time,depth_phase,anp_dep,ph_dep,ffn_dep]=depth_phase_spectrum(file_choose(i).name,window_length,datalength,M,path); %%depth_phase spectrum
semilogx(ffn,log10(anp_dep),'color',[0.6,0.6,0.6]);hold on;xlabel('time');ylabel('azimuth');
xlabel('frequency (Hz)'); ylabel('amplitude log10(Nm)'); title('spectra of depth phases');
 xlim([0.007,1]);
end
print ('-dpdf','depth_phase_spectra.pdf');close all;


%%% synthtic spectra, comparing with the average spectra
decay_n=2.3; % the decay rate at high frequency
fc=0.1; % the corner frequency
M0=1.1*10^20; % the amplitude of the low-frequency limit; moment
Mw=2/3*(log10(M0)-9.1);
figure;
semilogx(ffn,mean(amp3),'-','linewidth',3,'color','red');hold on;
% semilogx(ffn,mean(amp2),'-','linewidth',3,'color','b');
% semilogx(ffn,mean(amp1),'-','linewidth',3,'color',[0.5,0.5,0.5]);
xlabel('frequency (Hz)'); ylabel('amplitude (Nm)'); title('spectra fit');
for i=1:length(fc)
    for j=1:length(ffn)
    anp_syn(i,j)=log10(M0/(1+(ffn(j)^decay_n)/(fc(i)^decay_n)));
    end
    semilogx(ffn,anp_syn(i,:),'--','linewidth',2,'color','blue');hold on;
    xlim([0.007,1]);
end
legend('spectrum after correction','synthetic spectrum');
print('-dpdf','spectra_fitting.pdf');close all;

% calculate stress drop
vp=3900;%km/s
stress_drop=M0*(fc/0.42/vp)^3/10^6;%MPa






