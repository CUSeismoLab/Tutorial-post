function [T_sP,Amp_sP]=depth_phase_sP(dist,depth,Azi,M)
%% --------------------------------------------------------------------------
% Calculate the arriving time and amplitude for the sP phase
% T_sP is the time after direct P arrival
% Amp_sP is the amplitude of the sP phase
%
% [T_sP,Amp_sP]=depth_phase_sP(dist,depth,Azi,M)
%
% dist is the source-station great circle arc distance (in degree)
%
% depth is the depth of the source (in km)
%
% Azi is the azimuth of the station compared with the source
%
% M is the moment tensor in the Matlab coordinate (x-north;y-west;z-up)
% if moment tensor is in other coordinate system, need to be transform
% first: e.g.   GCMT x-t-south;y-p-east;z-r-up
%               Aki book: x-north;y-east;z-down
%
%% --------------------------------------------------------------------------


Radius=6371; % radius of the earth
rho=2700; % source region density

%% To read the IASP91 model (velocity and ray parameters)
ray_p_dep0=load('/DATA2/spectral_analysis/2015-04-25-mww78-nepal-2/depth_phase/TT_M/rayparam_iasp_P_H'); %source depth (km)
ray_p_temp=load('/DATA2/spectral_analysis/2015-04-25-mww78-nepal-2/depth_phase/TT_M/rayparam_iasp_P'); % ray parameter (s/km)
% IASP91 model (depth(km), radius(km), Vp(km/s), Vs(km/s))
ISAP91=load('/DATA2/spectral_analysis/2015-04-25-mww78-nepal-2/depth_phase/TT_M/isap91.txt'); 

%% Source region velocity and ray parameter from interpolation of IASP91 model
isap_dep0=ISAP91(:,1); % depth column (km)
isap_Vp0=ISAP91(:,3); % Vp column (km/s)
isap_Vs0=ISAP91(:,4); % Vs column (km/s)

%% To get the Vp, Vs (slowness) in the source and station region
Vp_source=interp1(isap_dep0,isap_Vp0,depth,'Linear'); % Vp in source (km/s)
Vs_source=interp1(isap_dep0,isap_Vs0,depth,'Linear'); % Vs in source (km/s)


%% To get Ray parameters
RP_dist0=ray_p_temp(:,1); % in degree
RP=ray_p_temp(:,2:end); % ray parameter in s/km

[dep0,dist0]=meshgrid(ray_p_dep0,RP_dist0);

Ndep0=length(ray_p_dep0);
Ndist0=length(RP_dist0);

DIST=20:0.01:96; % Distance for the ray parameter interpolation (in degree)
EV_DEP=ones(size(DIST))*depth; % source depth for ray parameter interpolation (km)

RP_EV=interp2(dep0,dist0,RP,EV_DEP,DIST,'linear'); % Direct P Ray parameter(source_depth,distance) in s/km

ray_p=interp1(DIST,RP_EV,dist,'Linear'); % the ray parameter of direct P wave (s/km)

ray_p_d=ray_p*111; % ray parameter in s/deg 
% Based on the relation from the relationship:
takeoff=asind(180/pi*Vp_source/(Radius-depth)*ray_p_d); % in degree


GS=geometrical_spreading(dist,depth);
Ray_len=1/sqrt(4*pi)/GS; % the ray length of the sP (in km)
dep_sta=depth+Ray_len*cosd(takeoff); %km

%% To determine the takeoff angle (incident angel also), ray parameter for the sP wave
% Based on the geometry, should solve the incident angle of the s wave and
% reflected P wave (sP)
in_sP_temp=1:0.001:90;
N_temp=length(in_sP_temp);
dif_temp=zeros(1,N_temp);

for i=1:N_temp
    dif_temp(i)=abs(depth*tand(in_sP_temp(i))+dep_sta*tand(asind(Vp_source/Vs_source*sind(in_sP_temp(i))))-Ray_len*sind(takeoff));
end

[temp,II]=min(dif_temp);

in_sP=in_sP_temp(II); % incident angle for the sP phase
ref_sP=asind(Vp_source/Vs_source*sind(in_sP)); % reflected angle for the sP phase

% travel time difference between P and sP
T_sP=depth/cosd(in_sP)/Vs_source+dep_sta/cosd(ref_sP)/Vp_source-Ray_len/Vp_source; %in s

%% Amp_sP
%  including radiation pattern, geometrical spreading and reflected coefficient

% Radiation pattern
takeoff2=180-in_sP; % takeoff angle for sP (i.e. the incident angle of s)
Radiation_sP=radiation_pattern(M,takeoff2,Azi,'S')...
    /(4*pi*rho*Vp_source^2*Vs_source*(depth/cosd(in_sP)+dep_sta/cosd(ref_sP))); 

% Reflection coefficients
%RC_sP=reflection_coef(Vp_source,Vs_source,in_sP,'SP');
RTmatrix=PSVRTmatrix(sind(in_sP)/Vs_source,[Vp_source Vs_source rho],[1.5 0.00001 1]);
RC_sP=-RTmatrix(4);

[R,L,A]=direct_P(dist,depth,Azi,M);

Amp_sP=Radiation_sP*RC_sP*GS*(-cosd(ref_sP))*(2*L*power(pi,0.5))*10^-12;% The last term means incoming Z(UP) component; unit s/N

end
