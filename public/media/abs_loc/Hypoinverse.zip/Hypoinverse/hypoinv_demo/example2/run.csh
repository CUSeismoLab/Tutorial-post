#!/bin/csh
#generate all input files and commands before running LOC

set phsfl="wy5300.phs"
set outarc="out.arc"
set outsum="out.sum"
set outprt="out.prt"
set hypfl="out.hyp"
#generate commands
echo "TYP 'Setting RongxianWeiyuan defaults' " >! $hypfl
echo "LET 4 2 3 2                     / Added by Freddy Aldersons" > $hypfl
#echo "LET 5 2 3 2 2                     / Added by Freddy Aldersons" >> $hypfl
echo "ERR 0.10                         /Standard timing error" >> $hypfl
echo "MIN 4                                   /Min number of stations" >> $hypfl
echo "POS 1.73                                /P to S ratio" >> $hypfl
echo "200 T 1900 0                    /enable y2000 formats" >> $hypfl
#echo "H71 1 1 3                       /use new hypoinverse station format" >> $hypfl 
echo "H71 1 1 3                       /Use hypo71 summary format for this test" >> $hypfl 
#output format

echo "ERF T                         /Send error messages to terminal" >> $hypfl
echo "DUR -.81 2.22 0 .0011 0, 5*0, 9999 1    /Set Eaton's duration magnitude" >> $hypfl
#**station data

#echo "TYP Read in stations: " >> $hypfl
echo "STA 'WY.sta'                      /read station file" >> $hypfl

#**CRUST MODEL
echo "TYP Read in crustal model(s): " >> $hypfl
#crustal model
echo "MUL T 1                   /use multiple crustal models"  >> $hypfl
echo "NOD 28 30 104 48 100 100 2        /define crust model 2: C08"  >> $hypfl
#echo "NOD 32 00 88 00 400 450 2        /define crust model 2: C08"  >> $hypfl
echo "CRH 1 'default.vel'                       /read crust model 1"  >> $hypfl
echo "CRH 2 'default.vel'                       /read crust model 2"  >> $hypfl
#set deafult phase files, archive files, summary files, print files
echo "PHS '$phsfl'            /input phase file" >> $hypfl
echo "FIL                             /automatically set phase format from file" >> $hypfl
echo "ARC '$outarc'               /output archive file" >> $hypfl
echo "SUM '$outsum'            /output summary file" >> $hypfl          
echo "PRT '$outprt'          /output print file" >> $hypfl
echo "LOC                             /locate the earthquake" >> $hypfl

# run hypoinverse
./hyp1.40 <<END2
@$hypfl
STO
END2
