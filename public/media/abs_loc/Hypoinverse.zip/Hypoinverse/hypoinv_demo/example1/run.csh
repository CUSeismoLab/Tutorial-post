#!/bin/csh
#generate all input files and commands before running LOC

set phsfl="one.phs"
set outarc="one.arc"
set outsum="one.sum"
set outprt="one.prt"
set hypfl="one.hyp"
#generate commands
echo "TYP 'HYPOINVSER demo: example 1' /TYP: type" >! $hypfl
echo "LET 5 2 3 2                 / Sta 5 char; Net 2 char; Cmp 3 char; Loc 2 char"          > $hypfl
echo "ERR 0.10                    /Estimated reading and timing error(s)"                   >> $hypfl
echo "MIN 4                       /Event recorded by stations low than MIN will be skipped" >> $hypfl
echo "POS 1.73                    /Vp to Vs ratio, used to convert Vs velocity"             >> $hypfl
# enable y2000 formats, T:True; Year will only 2-digits will be regarded as 20xx
echo "200 T 2000 0                /Enable y2000 formats, T:True; "                          >> $hypfl
# 1: use hypoinverse format output; 1: use hypoinverse format input; 3: use new station format
echo "H71 1 1 3                   /Use hypo71 summary format for this test"                 >> $hypfl 
echo "ERF T                       /T: True; Send error messages to terminal"                >> $hypfl
#echo "TYP Read in stations: " >> $hypfl
echo "STA 'WY.sta'                /read station file"                                       >> $hypfl
#**CRUST MODEL
echo "TYP Read in crustal model(s): "                                                       >> $hypfl
#crustal model
echo "MUL T 1                     /use multiple crustal models"                             >> $hypfl
#   Lat_deg Lat min; Lon_deg lon_min; radius(km); decay_width(km)
echo "NOD 28 30 104 48 100 100 1  /define crust"                                            >> $hypfl
echo "CRH 1 'default.vel'         /read crust model 1"                                      >> $hypfl
#set deafult phase files, archive files, summary files, print files
echo "PHS '$phsfl'                /input phase file"                                        >> $hypfl
echo "FIL                         /automatically adjust input phase file format"            >> $hypfl
echo "ARC '$outarc'               /output archive file"                                     >> $hypfl
echo "SUM '$outsum'               /output summary file"                                     >> $hypfl          
echo "PRT '$outprt'               /output print file"                                       >> $hypfl
echo "LOC                         /locate the earthquake"                                   >> $hypfl

# run hypoinverse
./hyp1.40 <<END2
@$hypfl
STO
END2
